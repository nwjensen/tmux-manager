"""TMUX Fleet Dashboard Backend"""

__version__ = "1.0.0"
